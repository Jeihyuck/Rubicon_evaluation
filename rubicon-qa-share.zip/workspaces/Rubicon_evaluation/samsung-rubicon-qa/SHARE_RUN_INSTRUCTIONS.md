# Share Run Instructions

이 압축 파일은 실행 코드와 테스트, 예시 환경설정 파일만 포함한다.

바로 실행 전 필수 준비:

1. Python 3.12 이상
2. `pip install -r requirements.txt`
3. `python -m playwright install chromium`
4. `cp .env.example .env`
5. `.env`에 `OPENAI_API_KEY` 설정

선택 준비:

- 삼성 로그인 세션을 재사용하려면 `.secrets/samsung_storage_state.json`을 별도로 전달받아 같은 위치에 둔다.
- 세션 파일이 없으면 공개 페이지 기준으로 새 브라우저 세션에서 실행된다.

실행 명령:

```bash
python run.py
```

결과 확인 순서:

1. `reports/latest_conversation.md`
2. `reports/latest_results.json`
3. `reports/latest_results.csv`
4. `reports/summary.md`

주의:

- 공유 zip에는 `.env`, `.secrets`, `.git`, `artifacts`, `__pycache__`를 넣지 않았다.
- OpenAI 평가 단계는 API quota 상태에 따라 실패할 수 있다.